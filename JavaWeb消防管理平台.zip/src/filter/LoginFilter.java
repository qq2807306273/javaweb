package filter;

import bean.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.PrintWriter;

@WebFilter("/admin/*")
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out=resp.getWriter();
        //如果从session域中能够获取到user用户，那就证明已经登录，是合法用户。
        HttpServletRequest request=(HttpServletRequest) req;
        if (request.getServletPath().equals("/admin/login.jsp")||request.getServletPath().equals("/admin/LoginServlet")||request.getServletPath().endsWith(".css")){
            chain.doFilter(req, resp);
        }else {
            User user=(User)request.getSession().getAttribute("user");
            if (user!=null){
                chain.doFilter(req, resp);
            }
            //否则是非法用户，返回登录页面
            else {
                out.print("<script>alert('非法用户，请登录！');document.location.href='"+request.getContextPath()+"/admin/login.jsp'</script>");
            }
        }


    }

    public void init(FilterConfig config) throws ServletException {

    }

}
