package dao;

import bean.News;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import utils.DataSourceUtils;

import java.sql.SQLException;
import java.util.List;

public class NewsDao {
    private QueryRunner runner=new QueryRunner(DataSourceUtils.getDataSource());
    /**
     * 增加
     */
    public boolean add(News news) throws SQLException {
        String sql="insert into news(title,content,tdate,itemid) values(?,?,?,?)";
        int n=runner.update(sql,news.getTitle(),news.getContent(),news.getTdate(),news.getItemid());
        if(n>0){
            return true;
        }
        else{
            return false;
        }
    }
    /**
     * 删除
     */
    public boolean delete(int id) throws SQLException {
        String sql="delete from news where id=?";
        int n=runner.update(sql,id);
        if(n>0){
            return true;
        }
        return false;
    }
    /**
     * 修改
     */
    public boolean update(News news) throws SQLException {
        String sql="update news set title=?,content=?,tdate=?,itemid=? where id=?";
        int n=runner.update(sql,news.getTitle(),news.getContent(),news.getTdate(),news.getItemid(),news.getId());
        if(n>0){
            return true;
        }
        return false;
    }
    /**
     * 根据id查找
     */
    public News findById(int id) throws SQLException {
        String sql="select * from news where id=?";
        News news=runner.query(sql,new BeanHandler<>(News.class),id);
        return news;
    }
    //查询所有
    public List<News> findAll() throws SQLException {
        String sql="select * from news";
        List<News> list=runner.query(sql,new BeanListHandler<>(News.class));
        return list;
    }

    //批量删除（参数：选中要删除的栏目ID数组）
    public boolean deleteCheckedArticle(String str[]) throws SQLException {
        //需要将字符串数组转换成以逗号分割的字符串
        String arr="";
        for (int i=0;i<str.length;i++){
            arr=arr+str[i]+",";
        }
        //"12,13,14,"，把最后一个逗号去掉
        arr=arr.substring(0,arr.length()-1);
        String sql="delete from news where id in("+arr+")";
        int n=runner.update(sql);
        if (n>0){
            return true;
        }
        return false;
    }
}
