package dao;

import bean.ItemNews;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import utils.DataSourceUtils;

import java.sql.SQLException;
import java.util.List;

public class ItemNewsDao {
    private QueryRunner runner=new QueryRunner(DataSourceUtils.getDataSource());
    //根据ID查询单个新闻
    public  ItemNews getNewsById(int id) throws SQLException {
        String sql="select * from item_news where id=?";
        return runner.query(sql,new BeanHandler<>(ItemNews.class),id);

    }
    //查询所有
    public  List<ItemNews> getAllNews() throws SQLException {
        String sql="select * from item_news";
        return runner.query(sql,new BeanListHandler<>(ItemNews.class));
    }
    //根据栏目ID查询该栏目下所有的新闻
    public List<ItemNews> getNewsByItemId(int itemid) throws SQLException {
        String sql="select * from item_news where itemid=? order by tdate desc";
        return runner.query(sql,new BeanListHandler<>(ItemNews.class),itemid);

    }
    // 根据栏目ID查询该栏目下前六条新闻
    public  List<ItemNews> getNewsByItemTop(int itemid) throws SQLException {
        String sql="select * from item_news where itemid=? order by tdate desc limit 0,6";
        return runner.query(sql,new BeanListHandler<>(ItemNews.class),itemid);
    }

    //查询每页新闻数据
    public List<ItemNews> getPageNews(int startIndex,int pageSize,int itemid,String title) throws SQLException {
        //如果参数传入的itemid=0，代表不选择特定栏目
        if(itemid==0){
            String sql="select * from item_news where title like '%"+title+"%' order by tdate desc,id desc limit ?,?";
            return runner.query(sql,new BeanListHandler<>(ItemNews.class),startIndex,pageSize);
        }
        else{
            String sql="select * from item_news where itemid=? and title like '%"+title+"%' order by tdate desc,id desc limit ?,?";
            return runner.query(sql,new BeanListHandler<>(ItemNews.class),itemid,startIndex,pageSize);
        }

    }

    //查询某个栏目下，新闻题目包含某些特定字符的新闻总条数
    public int getTotalRecords(int itemid,String title) throws SQLException {
        long num=0;
        //如果参数传入的itemid=0，代表不选择特定栏目，查询所有的新闻总条数
        if(itemid==0){
            String sql="select count(*) tn from item_news where title like '%"+title+"%'";
           num= (Long) runner.query(sql,new ScalarHandler("tn"));
        }
        else{
            String sql="select count(*) tn from item_news where itemid=? and title like '%"+title+"%'";
           num= (Long) runner.query(sql,new ScalarHandler("tn"),itemid);

        }
        //将long类型转成int
        String snum=String.valueOf(num);
        int inum=Integer.parseInt(snum);
        return inum;
    }



}
