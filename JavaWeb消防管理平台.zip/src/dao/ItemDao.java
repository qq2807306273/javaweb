package dao;

import bean.Items;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import utils.DataSourceUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDao {
    private QueryRunner runner=new QueryRunner(DataSourceUtils.getDataSource());
    //删除
    public boolean deleteItems(int id) throws SQLException {
        String sql="delete from itemt where id=?";
        int n=runner.update(sql,id);
        if(n>0){
            return true;
        }
        return false;
    }
    //增加
    public boolean addItems(Items items) throws SQLException {
        String sql="insert into itemt(itemname) values(?)";
        int n=runner.update(sql,items.getItemname());
        if(n>0){
            return true;
        }
        return false;

    }
    //修改
    public boolean updateItems(Items items) throws SQLException {
        String sql="update itemt set itemname=? where id=?";
        int n=runner.update(sql,items.getItemname(),items.getId());
        if(n>0){
            return true;
        }
        return false;
    }
    //查询所有
    public List<Items> getAllItems() throws SQLException {
        String sql="select * from itemt";
        List<Items> list=new ArrayList<>();
        list=runner.query(sql,new BeanListHandler<>(Items.class));
        return list;
    }
    //根据ID查询单个
    public Items getItemById(int id) throws SQLException {
        String sql="select * from itemt where id=?";
        Items items=runner.query(sql,new BeanHandler<>(Items.class),id);
        return items;
    }

    //批量删除（参数：选中要删除的栏目ID数组）
    public boolean deleteCheckedItem(String str[]) throws SQLException {
        //需要将字符串数组转换成以逗号分割的字符串
        String arr="";
        for (int i=0;i<str.length;i++){
            arr=arr+str[i]+",";
        }
        //"12,13,14,"，把最后一个逗号去掉
        arr=arr.substring(0,arr.length()-1);
        String sql="delete from itemt where id in("+arr+")";
        int n=runner.update(sql);
        if (n>0){
            return true;
        }
        return false;
    }

}
