package dao;

import bean.User;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import utils.DataSourceUtils;

import java.sql.SQLException;
import java.util.List;

public class UserDao {
    QueryRunner runner=new QueryRunner(DataSourceUtils.getDataSource());
    //增加
    public boolean add(User user) throws SQLException {

        String sql="insert into user(username,password,tdate,email) values (?,?,?,?)";
        int n=runner.update(sql,user.getUsername(),user.getPassword(),user.getTdate(),user.getEmail());
        if(n>0){
            return true;
        }
        return false;
    }
    //删除
    public boolean delete(int id) throws SQLException {
        String sql="delete from user where id=?";
        int n=runner.update(sql,id);
        if(n>0){
            return true;
        }
        return false;
    }
    //修改
    public boolean update(User user) throws SQLException {
        String sql="update user set username=?,password=?,tdate=?,email=? where id=?";
        int n=runner.update(sql,user.getUsername(),user.getPassword(),user.getTdate(),user.getEmail(),user.getId());
        if(n>0){
            return true;
        }
        return false;
    }
    //按照ID查询单个
    public User getUserById(int id) throws SQLException {
        String sql="select * from user where id=?";
        User user=runner.query(sql,new BeanHandler<>(User.class),id);
        return user;
    }

    //查询所有
    public List<User> getUser() throws SQLException {
        String sql="select * from user";
        List<User> list=runner.query(sql,new BeanListHandler<>(User.class));
        return list;
    }

    //按照用户名和密码查询用户
    public User getUserByNameAndPsw(String username,String password) throws SQLException {
        String sql = "select * from user where username=? and password=?";
        User user=runner.query(sql,new BeanHandler<>(User.class),username,password);
        return user;
    }
}
