package service;

import bean.Items;
import dao.ItemDao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemService {
    //创建ItemDao对象，调用dao层方法
    private ItemDao itemDao=new ItemDao();

    /**
     * 根据栏目ID删除栏目
     * @param id
     * @return
     */
    public boolean deleteItems(int id){
        try {
            return  itemDao.deleteItems(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 增加栏目
     * @param items
     * @return
     */
    public boolean addItems(Items items){
        try {
            boolean b=itemDao.addItems(items);
            if(b){
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 修改栏目
     * @param items
     * @return
     */
    public boolean updateItems(Items items){
        try {
            return itemDao.updateItems(items);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 获取所有栏目
     * @return
     */

    public List<Items> getAllItems(){
        List<Items> list=new ArrayList<>();
        try {
            list=itemDao.getAllItems();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    /**
     * 根据id查询栏目对象
     * @return
     */
    public Items getItemById(int id){
        try {
            return itemDao.getItemById(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 批量删除
     */
    public boolean deleteCheckedItem(String str[]){
        try {
            return itemDao.deleteCheckedItem(str);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
