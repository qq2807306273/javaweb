package service;

import bean.User;
import dao.UserDao;

import java.sql.SQLException;
import java.util.List;

//调用UserDao的增删改查方法
public class UserService {
    UserDao userDao=new UserDao();
    //增加
    public boolean addUser(User user){
        try {
            return userDao.add(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    //删除
    public boolean delete(int id){
        try {
            return userDao.delete(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    //修改
    public boolean update(User user){
        try {
            return userDao.update(user);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    //查询单个
    public User getUserById(int id){
        try {
            return userDao.getUserById(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //查询所有
    public List<User> getUser(){
        try {
            return userDao.getUser();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    //按照用户名和密码查询用户
    public User getUserByNameAndPsw(String name,String password){
        try {
            return userDao.getUserByNameAndPsw(name, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
