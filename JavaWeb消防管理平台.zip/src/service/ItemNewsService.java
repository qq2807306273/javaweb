package service;

import bean.ItemNews;
import bean.PageBean;
import dao.ItemNewsDao;

import java.sql.SQLException;
import java.util.List;

public class ItemNewsService {
    ItemNewsDao itemNewsDao=new ItemNewsDao();
    //得到所有新闻
    public List<ItemNews> getAllNews(){
        try {
            return itemNewsDao.getAllNews();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //根据栏目ID得到该栏目下的所有新闻
    public List<ItemNews> getNewsByItem(int itemid){
        try {
            return itemNewsDao.getNewsByItemId(itemid);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //根据栏目ID查询该栏目下的前6条文章
    public List<ItemNews> getNewsByItemTop(int itemid){
        try {
            return   itemNewsDao.getNewsByItemTop(itemid);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  null;
    }
    //根据新闻id查询某个新闻
    public ItemNews getNewsById(int id){
        try {
            return itemNewsDao.getNewsById(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    //获取pageBean对象
    public PageBean getPageBean(int pageSize,int pageNum,int itemid,String title){
        try {
            //调用ItemNewsDao的getTotalRecords(itemid,title)获取新闻总条数，目的为了给pagebean的构造方法传参
            int totalRecord=new ItemNewsDao().getTotalRecords(itemid,title);

            //创建pageBean对象，需要知道三个参数 public PageBean(int pageSize,int pageNum,int totalRecord)
            PageBean pageBean=new PageBean(pageSize,pageNum,totalRecord);

            //pagebean还有一个属性每页新闻数据list没有赋值
            int startIndex=pageBean.getStartIndex();//获取pagebean对象的startIndex每页新闻起始索引，目的为了查询每页新闻数据时传参
            //调用ItemNewsDao的getPageNews(int startIndex,int pageSize,int itemid,String title)方法获取每页新闻数据
            List<ItemNews> list=new ItemNewsDao().getPageNews(startIndex,pageSize,itemid,title);

            pageBean.setList(list);//为pagebean的属性每页新闻数据list进行赋值，至此pagebean所有的属性赋值完毕

            return pageBean;//返回pagebean对象

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
