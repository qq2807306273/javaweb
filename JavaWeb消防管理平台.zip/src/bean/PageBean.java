package bean;

import java.util.List;

public class PageBean {
    //已知数据
    private int pageSize;//每页新闻数量----自己设定
    private int pageNum;//当前页号-----传递过来的参数的值

    //未知数据
    private int totalRecord;//总的新闻条数----从数据库查询得到
    private int startIndex;//每页的新闻起始索引-----由两个已知数据就可以计算得到（pageNum-1)*pageSize
    private int totalPage; //总的页面数量，由totalRecord(总的新闻条数)与pageSize（每页新闻数量）计算得到
    private List<ItemNews> list;//当前页面的新闻数据，从数据库查询得到，从每页的新闻起始索引开始，查询pageSize（每页新闻数量）条数据

    //有参的构造方法
    public PageBean(int pageSize,int pageNum,int totalRecord){
        this.pageSize=pageSize;
        this.pageNum=pageNum;
        this.totalRecord=totalRecord;
        this.startIndex=(pageNum-1)*pageSize;//每页的新闻起始索引-----由两个已知数据就可以计算得到（pageNum-1)*pageSize
        //总的页面数量，由totalRecord(总的新闻条数)与pageSize（每页新闻数量）计算得到
        if(totalRecord%pageSize==0){//如果能整除，总页数就等于两者的商
            this.totalPage=totalRecord/pageSize;
        }
        else{//如果不能整除，总页数等于两者的商+1
            this.totalPage=totalRecord/pageSize+1;
        }
    }
    //无参的构造方法
    public PageBean(){

    }
    //公共的set/get方法
    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ItemNews> getList() {
        return list;
    }

    public void setList(List<ItemNews> list) {
        this.list = list;
    }

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }
}
