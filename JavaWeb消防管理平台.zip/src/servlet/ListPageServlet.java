package servlet;

import bean.Items;
import bean.PageBean;
import service.ItemNewsService;
import service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

//从首页点击每个新闻栏目后面的more过来，获取该栏目，查询该栏目下所有的新闻，查询所有的栏目，最终跳转至列表页显示数据
/*
列表页需要显示的数据：
左边-----左上侧（栏目标题）   左下侧（所有栏目）
右边-----右上侧（栏目标题）    右下侧（分页对象）
需要在servlet中获取这几部分数据，然后存入域中，传递至list.jsp列表页显示数据
 */
@WebServlet("/ListPageServlet")
public class ListPageServlet extends HttpServlet {
    ItemService itemService=new ItemService();
    ItemNewsService itemNewsService=new ItemNewsService();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1、根据参数itemid获取点击的栏目
        String sitemid=request.getParameter("itemid");
        Items items=itemService.getItemById(Integer.parseInt(sitemid));

        //2、获取所有的栏目
        List<Items> itemsList=itemService.getAllItems();

        //3、获取分页对象,ItemNewsService调用getPageBean(int pageSize,int pageNum,int itemid,String title)
            //3.1第一个参数int pageSize
        int pageSize=4;
            //3.2第二个参数int pageNum
        int pageNum;
        if(request.getParameter("pageNum")==null||Integer.parseInt(request.getParameter("pageNum"))<1){
            pageNum=1;
        }
        else{
            pageNum=Integer.parseInt(request.getParameter("pageNum"));
        }
            //3.3第三个参数int itemid
        int itemid=Integer.parseInt(sitemid);
            //3.4第四个参数String title
        String title="";
        PageBean pageBean=itemNewsService.getPageBean(pageSize,pageNum,itemid,title);

        //4、将数据存入域中
        request.setAttribute("items",items);
        request.setAttribute("itemsList",itemsList);
        request.setAttribute("pageBean",pageBean);

        //5、页面跳转
        request.getRequestDispatcher("/list.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
