package servlet.admin;

import bean.News;
import service.ItemService;
import service.NewsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

@WebServlet("/admin/ArticleAddServlet")
public class ArticleAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();

        String title=request.getParameter("title");
        String content=request.getParameter("content");
        String itemid=request.getParameter("itemid");
        Date date=new Date();

        News news=new News();
        news.setContent(content);
        news.setItemid(Integer.parseInt(itemid));
        news.setTitle(title);
        news.setTdate(date);

        boolean b=new NewsService().addNews(news);
        if (b){
            out.print("<script>alert('添加成功');document.location.href='"+request.getContextPath()+"/admin/ArticleServlet';</script>");
        }else {
            out.print("<script>alert('添加失败');document.location.href='"+request.getContextPath()+"/admin/ArticleServlet';</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
