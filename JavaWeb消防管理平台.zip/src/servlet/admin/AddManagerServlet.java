package servlet.admin;

import bean.User;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.SimpleFormatter;

@WebServlet("/admin/AddManagerServlet")
public class AddManagerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();

        //获取数据
        String password=request.getParameter("password");
        String password2=request.getParameter("password_confirm");
        String username=request.getParameter("user_name");
        String email=request.getParameter("email");
        String tdate=request.getParameter("tdate");
        //验证密码是否正确
        if (password.equals(password2)){
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            user.setEmail(email);
            try {
                user.setTdate(new SimpleDateFormat("yyyy-MM-dd").parse(tdate));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            //user.setTdate();
            boolean b=new UserService().addUser(user);
            if (b){
                out.print("<script>alert('添加成功！');document.location.href='"+request.getContextPath()+"/admin/ManagerServlet';</script>");
            }else {
                out.print("<script>alert('添加失败！');document.location.href='"+request.getContextPath()+"/admin/ManagerServlet';</script>");
            }
        }else {
            request.setAttribute("error","密码不一致◔ ‸◔?");
            out.print("<script>alert('密码不一致！');document.location.href='"+request.getContextPath()+"/admin/manageradd.jsp';</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
