package servlet.admin;

import bean.User;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/admin/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();

        //获取登录页面的信息
        String username= request.getParameter("username");
        String psw=request.getParameter("password");

        //从数据库中查询用户
        UserService userService=new UserService();
        User user=userService.getUserByNameAndPsw(username,psw);
        if (user!=null){//查到是合法用户登录后台
            request.getSession().setAttribute("user",user);
            response.sendRedirect(request.getContextPath()+"/admin/index.jsp");
//            request.getRequestDispatcher("/admin/index.jsp").forward(request,response);
//            return;
            }else{        //否则，非法用户返回登录页面
            out.print("<script>alert('用户名或密码不正确，请重新输入！');document.location.href='"+request.getContextPath()+"/admin/login.jsp'</script>");
//            request.getRequestDispatcher("/admin/login.jsp").forward(request,response);
//            return;
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
