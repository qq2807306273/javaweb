package servlet.admin;

import service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/admin/CategoryCheckedDeleteServlet")
public class CategoryCheckedDeleteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();

        //获取复选框的选择结果（批量选中的栏目ID）
        String values[]=request.getParameterValues("checkbox[]");//[12,13,14]------"12,13,14"
        boolean f=new ItemService().deleteCheckedItem(values);
        if (f){
            out.print("<script>alert('删除成功');document.location.href='"+request.getContextPath()+"/admin/CategoryServlet';</script>");
        }else{
            out.print("<script>alert('删除失败');document.location.href='"+request.getContextPath()+"/admin/CategoryServlet';</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
