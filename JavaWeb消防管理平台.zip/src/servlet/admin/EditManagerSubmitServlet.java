package servlet.admin;

import bean.User;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/admin/EditManagerSubmitServlet")
public class EditManagerSubmitServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //编码格式
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();
        //获取修改的数据信息
        int id=Integer.parseInt(request.getParameter("id"));
        String password=request.getParameter("password");
        String password2=request.getParameter("password_confirm");
        String username=request.getParameter("user_name");
        String email=request.getParameter("email");
//        String tdate=request.getParameter("tdate");

        if (password.equals(password2)) {
            String mydate=request.getParameter("tdate");
            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date tdate=simpleDateFormat.parse(mydate);
                User user=new User(id,username,password,tdate,email);
                UserService userService=new UserService();
                boolean b=userService.update(user);
                if (b){
                    out.print("<script>alert('修改成功！');document.location.href='"+request.getContextPath()+"/admin/ManagerServlet';</script>");
                }else{
                    out.print("<script>alert('修改失败！');document.location.href='"+request.getContextPath()+"/admin/ManagerServlet';</script>");
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }else {
            request.setAttribute("error","密码不一致◔ ‸◔?");
            out.print("<script>alert('密码不一致！');document.location.href='"+request.getContextPath()+"/admin/manager.jsp';</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
