package servlet.admin;

import bean.User;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/ManagerEditServlet")
public class ManagerEditServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取要编辑的数据
        int id=Integer.parseInt(request.getParameter("id"));
        User user=new UserService().getUserById(id);
        //存入域中
        request.setAttribute("user",user);
        //跳转到编辑页面
        request.getRequestDispatcher("/admin/manageredit.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
