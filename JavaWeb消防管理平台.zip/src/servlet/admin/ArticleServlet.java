package servlet.admin;

import bean.Items;
import bean.PageBean;
import service.ItemNewsService;
import service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/ArticleServlet")
public class ArticleServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        request.setCharacterEncoding("utf-8");
        //获取分页对象
        //getPageBean(int pageSize,int pageNum,int itemid,String title)
        int pageSize=3;
        int pageNum;
        if (request.getParameter("pageNum")==null||Integer.parseInt(request.getParameter("pageNum"))<1){
            pageNum=1;
        }else {
            pageNum=Integer.parseInt(request.getParameter("pageNum"));
        }

        //
        int itemid=0;
        String sitemid=request.getParameter("cat_id");
        //如果不做任何筛选，获取到的值为“0”，代表选择未分类，这两种情况意味着不做任何栏目的筛选
        if (sitemid==null||sitemid.equals("0")){
            itemid=0;
        }else {
            itemid=Integer.parseInt(sitemid);
        }

        //
        String title=request.getParameter("keyword");
        if (title==null){
            title="";
        }
        //
        PageBean pageBean=new ItemNewsService().getPageBean(pageSize,pageNum,itemid,title);
        request.setAttribute("pageBean",pageBean);

        //文章列表栏目需添加内容：
        List<Items> list=new ItemService().getAllItems();
        request.setAttribute("list",list);

        request.setAttribute("cat_id",itemid);
        request.setAttribute("keyword",title);
        request.getRequestDispatcher("/admin/article.jsp").forward(request,response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
