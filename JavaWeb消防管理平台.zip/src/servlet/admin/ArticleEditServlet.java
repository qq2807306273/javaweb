package servlet.admin;

import bean.ItemNews;
import bean.Items;
import service.ItemNewsService;
import service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/ArticleEditServlet")
public class ArticleEditServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //查询要编辑的文章，存入域中
        String id=request.getParameter("id");
        ItemNews itemNews=new ItemNewsService().getNewsById(Integer.parseInt(id));
        request.setAttribute("itemNews",itemNews);

        //查询所有的栏目，存入域中，以便在下拉列表中选择文章所属栏目
        List<Items> list=new ItemService().getAllItems();
        request.setAttribute("list",list);

        //跳转
        request.getRequestDispatcher("/admin/articleedit.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
