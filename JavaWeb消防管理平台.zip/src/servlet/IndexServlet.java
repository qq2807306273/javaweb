package servlet;

import bean.ItemNews;
import service.ItemNewsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

//到数据库中查询每个栏目下的前六条新闻，存到域中进行数据传递，跳转至网站首页
@WebServlet("/IndexServlet")
public class IndexServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ItemNewsService itemNewsService=new ItemNewsService();
        List<ItemNews> listxwdt= itemNewsService.getNewsByItemTop(1);//查询“新闻动态”栏目下的前六条新闻
        List<ItemNews> listsszx= itemNewsService.getNewsByItemTop(2);//查询“实时资讯”栏目下的前六条新闻
        List<ItemNews> listkszx= itemNewsService.getNewsByItemTop(3);//查询“考试资讯”栏目下的前六条新闻
        List<ItemNews> listxfgcs1= itemNewsService.getNewsByItemTop(4);//查询“新闻动态”栏目下的前六条新闻
        List<ItemNews> listxfgcs2= itemNewsService.getNewsByItemTop(5);//查询“新闻动态”栏目下的前六条新闻
        //将查到的数据存入域中
        request.setAttribute("listxwdt",listxwdt);
        request.setAttribute("listsszx",listsszx);
        request.setAttribute("listkszx",listkszx);
        request.setAttribute("listxfgcs1",listxfgcs1);
        request.setAttribute("listxfgcs2",listxfgcs2);
        //跳转至网站首页
        request.getRequestDispatcher("/myindex.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
