package servlet;

import bean.ItemNews;
import bean.Items;
import service.ItemNewsService;
import service.ItemService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/ListServlet")
public class ListServlet extends HttpServlet {
    private ItemNewsService itemNewsService=new ItemNewsService();//创建ItemNewsService对象
    private ItemService itemService=new ItemService();//创建ItemService对象
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获得栏目ID
        int itemid=Integer.parseInt(request.getParameter("itemid"));
        //根据栏目ID获得栏目(从而在显示的列表页获得栏目名）
        Items items=itemService.getItemById(itemid);
        //根据栏目ID获得所有栏目（在左侧显示栏目列表）
        List<Items> itemsList=itemService.getAllItems();

        //根据栏目ID获得该栏目下所有的文章
        List<ItemNews> itemNewslist=itemNewsService.getNewsByItem(itemid);

        //将数据存入request域
        request.setAttribute("items",items);
        request.setAttribute("itemsList",itemsList);
        request.setAttribute("itemNewslist",itemNewslist);
        //转发至list.jsp列表页
        request.getRequestDispatcher(request.getContextPath()+"/list.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
