package utils;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class DataSourceUtils {
    //创建数据源对象
    private static DataSource dataSource=new ComboPooledDataSource();
    //获得数据源
    public static DataSource getDataSource(){
        return dataSource;
    }
    //创建线程池
    private static ThreadLocal<Connection> tl=new ThreadLocal();
    //获得连接
    public static Connection getConnection() throws SQLException {
        Connection connection=tl.get();//从线程池中获取连接
        //如果获取不到，意味着线程池中没有可用连接
        if(connection==null){
            //用数据源对象获取连接
            connection=dataSource.getConnection();
            tl.set(connection);//将新获取的连接放入线程池
        }
        return connection;
    }
    //开启事务
    public static void startTransaction() throws SQLException {
        Connection con=dataSource.getConnection();
        if(con!=null){
            con.setAutoCommit(false);
        }
    }
    //结束事务，释放、关闭连接
    public static void closeConnection() throws SQLException {
        Connection con=dataSource.getConnection();
        if(con!=null){
            con.commit();//提交事务
            tl.remove();//从线程池释放连接
            con.close();//关闭连接

        }
    }
    //事务回滚
    public static void rollBack() throws SQLException {
        Connection con=dataSource.getConnection();
        if(con!=null){
            con.rollback();
        }
    }

}
